#ifndef _CUST_BAT_I2C_H_
#define _CUST_BAT_I2C_H_

#define BQ24196_BUSNUM 6

#endif /* _CUST_BAT_I2C_H_ */